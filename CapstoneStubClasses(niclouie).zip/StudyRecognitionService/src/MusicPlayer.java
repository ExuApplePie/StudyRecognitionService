/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author 84038001
 */
public class MusicPlayer {
 public MusicPlayer(){
     
 }   
 
 public void playMusic() {
     
 }
 
 public void pauseMusic() {
     
 }
 
 public void shuffleMusic() {
     
 }
 
 public void repeatMusic() {
     
 }
 public void skipSong() {
     
 }
 public void playLastSong() {
     
 } 
 public void setVolume(int volume) {
     
 }
 public String getSong() {
     return "";
 }
}
