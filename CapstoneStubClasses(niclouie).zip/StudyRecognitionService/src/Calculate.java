/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author 84038001
 */
public class Calculate {
    public Calculate() {
        
    }
    
    public static double calculateTime(int startTime) {
        return 0.0;
    }
}
