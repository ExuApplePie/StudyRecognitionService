/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author 84038001
 */
public class SRS {
    public SRS(){
        
    }
    
    public void setDictionary(String path) {
        //calls StudyFiles.readFile()
    }
    
    public int getScore() {
        return 0;
    }
    
    private void setScore() {
        //calls calculateScore
    }
    
    private void calculateScore() { //factor out calculations
        
    }
    
    public String displayQuestion() {
        return null;
    }
    
}
