/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author 84038001
 */
public class Timer {
    public Timer(){
        
    }
    
    public void startTimer(){
        
    }
    public void stopTimer(){
        
    }
    public void playNoise(){
        
    }
    public void setNoise() {
        
    }
}
